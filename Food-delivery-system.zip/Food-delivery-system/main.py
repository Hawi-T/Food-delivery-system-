import gspread
from oauth2client.service_account import ServiceAccountCredentials
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import random
import string
from datetime import datetime, timedelta
import bcrypt
import json
import os
import logging
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)

scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
credentials_json = json.loads(os.getenv('GOOGLE_CREDENTIALS', '{}'))
creds = ServiceAccountCredentials.from_json_keyfile_dict(credentials_json, scope)
client = gspread.authorize(creds)

try:
    spreadsheet = client.open("food delivery data base")
except Exception:
    spreadsheet = None

MENU_SHEET = spreadsheet.worksheet('Menu') if spreadsheet else None
PENDING_SHEET = spreadsheet.worksheet('PendingOrders') if spreadsheet else None
DELIVERED_SHEET = spreadsheet.worksheet('DeliveredOrders') if spreadsheet else None
WORKERS_SHEET = spreadsheet.worksheet('Workers') if spreadsheet else None
ADMINS_SHEET = spreadsheet.worksheet('Admins') if spreadsheet else None
RATINGS_SHEET = spreadsheet.worksheet('FoodRatings') if spreadsheet else None

def clean_order_data(order, headers):
    cleaned_order = {}
    for key, value in zip(headers, order):
        if value is None:
            cleaned_order[key] = ''
        elif isinstance(value, (str, int, float)):
            cleaned_order[key] = str(value).strip()
        else:
            cleaned_order[key] = str(value)

    # Special handling for items
    items = cleaned_order.get('items', '')
    if not items:
        cleaned_order['items'] = '[]'
    else:
        try:
            json.loads(items)
            cleaned_order['items'] = items
        except json.JSONDecodeError:
            cleaned_order['items'] = '[]'

    return cleaned_order

@app.route('/')
def index():
    logging.info('Request: GET /')
    if not MENU_SHEET or not RATINGS_SHEET:
        logging.info('Response: GET / - Status: 200, Error: Unable to load menu or ratings')
        return render_template('index.html', menu=[], error="Unable to load menu or ratings")

    try:
        menu_items = MENU_SHEET.get_all_records()
        ratings_data = RATINGS_SHEET.get_all_records()
        ratings_dict = {r['food_name']: r for r in ratings_data}

        cleaned_menu = []
        for item in menu_items:
            try:
                item['Price'] = float(item.get('Price', 0))
                rating_info = ratings_dict.get(item['Name'], {
                    'average_rating': 0.0,
                    'rating_count': 0,
                    'ratings': '[]'
                })
                item['average_rating'] = float(rating_info['average_rating'])
                item['rating_count'] = int(rating_info['rating_count'])
                cleaned_menu.append(item)
            except (ValueError, TypeError):
                item['Price'] = 0.0
                item['average_rating'] = 0.0
                item['rating_count'] = 0
                cleaned_menu.append(item)
        logging.info(f"Response: GET / - Status: 200, Menu items: {len(cleaned_menu)}")
        return render_template('index.html', menu=cleaned_menu)
    except Exception as e:
        logging.info(f"Response: GET / - Status: 200, Error: {str(e)}")
        return render_template('index.html', menu=[], error=str(e))

@app.route('/place_order', methods=['POST'])
def place_order():
    logging.info(f"Request: POST /place_order, Form data: {dict(request.form)}")
    if not PENDING_SHEET:
        logging.info('Response: POST /place_order - Status: 503, Error: Service unavailable')
        return jsonify({'success': False, 'error': 'Service unavailable'}), 503

    try:
        data = request.form
        items = json.loads(data.get('items', '[]'))
        if not isinstance(items, list):
            raise ValueError("Items must be a list")

        verification_code = ''.join(random.choices(string.digits, k=4))
        order = {
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'customer_name': data.get('customer_name', '').strip(),
            'address': data.get('address', '').strip(),
            'contact': data.get('contact', '').strip(),
            'items': json.dumps(items),
            'verification_code': verification_code,
            'status': 'pending'
        }

        if not all([order['customer_name'], order['address'], order['contact']]):
            raise ValueError("Missing required fields")

        PENDING_SHEET.append_row([
            order['timestamp'],
            order['customer_name'],
            order['address'],
            order['contact'],
            order['items'],
            order['verification_code']
        ])

        logging.info(f"Response: POST /place_order - Status: 200, Verification code: {verification_code}")
        return jsonify({'success': True, 'verification_code': verification_code})
    except Exception as e:
        logging.info(f"Response: POST /place_order - Status: 400, Error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/worker_login', methods=['GET', 'POST'])
def worker_login():
    if request.method == 'POST':
        logging.info(f"Request: POST /worker_login, Form data: {{'username': '{request.form.get('username')}', 'password': '<hidden>'}}")
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            logging.info('Response: POST /worker_login - Status: 200, Error: Please provide both username and password')
            return render_template('worker_login.html', error='Please provide both username and password')

        password = password.encode('utf-8')

        if not WORKERS_SHEET:
            logging.info('Response: POST /worker_login - Status: 200, Error: Service unavailable')
            return render_template('worker_login.html', error='Service unavailable')

        try:
            workers = WORKERS_SHEET.get_all_records()
            if not workers:
                logging.info('Response: POST /worker_login - Status: 200, Error: No workers registered')
                return render_template('worker_login.html', error='No workers registered')

            for worker in workers:
                worker_username = worker.get('username', '').strip()
                worker_password = worker.get('password', '').strip()
                if worker_username == username:
                    if not worker_password:
                        logging.info('Response: POST /worker_login - Status: 200, Error: Invalid credentials')
                        return render_template('worker_login.html', error='Invalid credentials')

                    try:
                        stored_password = worker_password.encode('utf-8')
                        if bcrypt.checkpw(password, stored_password):
                            session.pop('admin_id', None)
                            session['worker_id'] = username
                            session.permanent = True
                            logging.info(f"Response: POST /worker_login - Status: 302, Redirect: worker_dashboard")
                            return redirect(url_for('worker_dashboard'))
                    except ValueError:
                        logging.info('Response: POST /worker_login - Status: 200, Error: Invalid password format')
                        return render_template('worker_login.html', error='Invalid password format')

            logging.info('Response: POST /worker_login - Status: 200, Error: Invalid credentials')
            return render_template('worker_login.html', error='Invalid credentials')
        except Exception as e:
            logging.info(f"Response: POST /worker_login - Status: 200, Error: Error accessing workers: {str(e)}")
            return render_template('worker_login.html', error=f'Error accessing workers: {str(e)}')

    logging.info('Request: GET /worker_login')
    logging.info('Response: GET /worker_login - Status: 200')
    return render_template('worker_login.html')

@app.route('/worker_dashboard')
def worker_dashboard():
    logging.info('Request: GET /worker_dashboard')
    if 'worker_id' not in session:
        logging.info('Response: GET /worker_dashboard - Status: 302, Redirect: worker_login')
        return redirect(url_for('worker_login'))

    logging.info(f"Response: GET /worker_dashboard - Status: 200, Worker: {session['worker_id']}")
    return render_template('worker_dashboard.html', worker=session['worker_id'])

@app.route('/get_orders', methods=['GET'])
def get_orders():
    logging.info('Request: GET /get_orders')
    if not (PENDING_SHEET and DELIVERED_SHEET):
        logging.info('Response: GET /get_orders - Status: 503, Error: Service unavailable')
        return jsonify({'success': False, 'error': 'Service unavailable'}), 503

    try:
        pending_headers = PENDING_SHEET.row_values(1) or ['timestamp', 'customer_name', 'address', 'contact', 'items', 'verification_code']
        pending_data = PENDING_SHEET.get_all_values()[1:]
        pending_orders = [clean_order_data(row, pending_headers) for row in pending_data]

        delivered_headers = DELIVERED_SHEET.row_values(1) or ['timestamp', 'customer_name', 'address', 'contact', 'items', 'worker', 'delivery_timestamp', 'verification_code']
        delivered_data = DELIVERED_SHEET.get_all_values()[1:]
        delivered_orders = [clean_order_data(row, delivered_headers) for row in delivered_data]

        logging.info(f"Response: GET /get_orders - Status: 200, Pending orders: {len(pending_orders)}, Delivered orders: {len(delivered_orders)}")
        return jsonify({
            'success': True,
            'pending_orders': pending_orders,
            'delivered_orders': delivered_orders
        })
    except Exception as e:
        logging.info(f"Response: GET /get_orders - Status: 500, Error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/mark_delivered', methods=['POST'])
def mark_delivered():
    logging.info(f"Request: POST /mark_delivered, Form data: {dict(request.form)}")
    if 'worker_id' not in session:
        logging.info('Response: POST /mark_delivered - Status: 401, Error: Unauthorized')
        return jsonify({'success': False, 'error': 'Unauthorized'}), 401

    if not (PENDING_SHEET and DELIVERED_SHEET):
        logging.info('Response: POST /mark_delivered - Status: 503, Error: Service unavailable')
        return jsonify({'success': False, 'error': 'Service unavailable'}), 503

    try:
        data = request.form
        order_id = data.get('order_id')
        verification_code = data.get('code')

        if not order_id or not verification_code:
            logging.info('Response: POST /mark_delivered - Status: 400, Error: Missing required fields')
            return jsonify({'success': False, 'error': 'Missing required fields'}), 400

        headers = PENDING_SHEET.row_values(1) or ['timestamp', 'customer_name', 'address', 'contact', 'items', 'verification_code']
        data = PENDING_SHEET.get_all_values()[1:]
        orders = [dict(zip(headers, row)) for row in data]

        for idx, order in enumerate(orders):
            if str(order.get('timestamp', '')) == order_id and order.get('verification_code', '') == verification_code:
                cleaned_order = clean_order_data(order.values(), headers)

                DELIVERED_SHEET.append_row([
                    cleaned_order['timestamp'],
                    cleaned_order['customer_name'],
                    cleaned_order['address'],
                    cleaned_order['contact'],
                    cleaned_order['items'],
                    session['worker_id'],
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    cleaned_order['verification_code']
                ])

                # Account for header row
                row_index = idx + 2
                PENDING_SHEET.delete_rows(row_index)

                logging.info(f"Response: POST /mark_delivered - Status: 200, Order: {order_id}")
                return jsonify({'success': True})

        logging.info('Response: POST /mark_delivered - Status: 400, Error: Invalid verification code or order')
        return jsonify({'success': False, 'error': 'Invalid verification code or order'}), 400
    except Exception as e:
        logging.info(f"Response: POST /mark_delivered - Status: 500, Error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/rating', methods=['GET'])
def rating():
    logging.info('Request: GET /rating')
    logging.info('Response: GET /rating - Status: 200')
    return render_template('rating.html')

@app.route('/get_delivered_orders_by_code', methods=['GET'])
def get_delivered_orders_by_code():
    logging.info(f"Request: GET /get_delivered_orders_by_code, Query: {dict(request.args)}")
    if not DELIVERED_SHEET or not RATINGS_SHEET:
        logging.info('Response: GET /get_delivered_orders_by_code - Status: 503, Error: Service unavailable')
        return jsonify({'success': False, 'error': 'Service unavailable'}), 503

    try:
        code = request.args.get('code')
        if not code:
            logging.info('Response: GET /get_delivered_orders_by_code - Status: 400, Error: Verification code required')
            return jsonify({'success': False, 'error': 'Verification code required'}), 400

        headers = DELIVERED_SHEET.row_values(1) or ['timestamp', 'customer_name', 'address', 'contact', 'items', 'worker', 'delivery_timestamp', 'verification_code']
        data = DELIVERED_SHEET.get_all_values()[1:]
        orders = [clean_order_data(row, headers) for row in data]
        ratings_data = RATINGS_SHEET.get_all_records()
        ratings_dict = {r['food_name']: r for r in ratings_data}

        matching_orders = []
        for order in orders:
            if order.get('verification_code') == code:
                items = json.loads(order.get('items', '[]'))
                for item in items:
                    rating_info = ratings_dict.get(item['name'], {
                        'average_rating': 0.0,
                        'rating_count': 0,
                        'ratings': '[]'
                    })
                    item['average_rating'] = float(rating_info['average_rating'])
                    item['rating_count'] = int(rating_info['rating_count'])
                    item['ratings'] = json.loads(rating_info['ratings'])
                order['items'] = items
                matching_orders.append(order)

        logging.info(f"Response: GET /get_delivered_orders_by_code - Status: 200, Orders found: {len(matching_orders)}")
        return jsonify({'success': True, 'orders': matching_orders})
    except Exception as e:
        logging.info(f"Response: GET /get_delivered_orders_by_code - Status: 500, Error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/submit_rating', methods=['POST'])
def submit_rating():
    logging.info(f"Request: POST /submit_rating, Form data: {dict(request.form)}")
    if not RATINGS_SHEET:
        logging.info('Response: POST /submit_rating - Status: 503, Error: Service unavailable')
        return jsonify({'success': False, 'error': 'Service unavailable'}), 503

    try:
        data = request.form
        food_name = data.get('food_name')
        rating = int(data.get('rating'))

        if not food_name or not (1 <= rating <= 5):
            logging.info('Response: POST /submit_rating - Status: 400, Error: Invalid food name or rating')
            return jsonify({'success': False, 'error': 'Invalid food name or rating'}), 400

        ratings_data = RATINGS_SHEET.get_all_records()
        ratings_dict = {r['food_name']: r for r in ratings_data}
        row_index = None
        for idx, r in enumerate(ratings_data):
            if r['food_name'] == food_name:
                row_index = idx + 2
                break

        if row_index:
            current_ratings = json.loads(ratings_dict[food_name]['ratings'])
            current_ratings.append(rating)
            rating_count = len(current_ratings)
            average_rating = sum(current_ratings) / rating_count
            RATINGS_SHEET.update(f'A{row_index}:D{row_index}', [[food_name, average_rating, rating_count, json.dumps(current_ratings)]])
        else:
            RATINGS_SHEET.append_row([food_name, rating, 1, json.dumps([rating])])

        logging.info(f"Response: POST /submit_rating - Status: 200, Food: {food_name}, Rating: {rating}")
        return jsonify({'success': True})
    except Exception as e:
        logging.info(f"Response: POST /submit_rating - Status: 500, Error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/logout')
def logout():
    logging.info('Request: GET /logout')
    session.pop('worker_id', None)
    session.pop('admin_id', None)
    logging.info('Response: GET /logout - Status: 302, Redirect: worker_login')
    return redirect(url_for('worker_login'))

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        logging.info(f"Request: POST /admin_login, Form data: {{'username': '{request.form.get('username')}', 'password': '<hidden>'}}")
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            logging.info('Response: POST /admin_login - Status: 200, Error: Please provide both username and password')
            return render_template('admin_login.html', error='Please provide both username and password')

        password = password.encode('utf-8')

        if not ADMINS_SHEET:
            logging.info('Response: POST /admin_login - Status: 200, Error: Service unavailable')
            return render_template('admin_login.html', error='Service unavailable')

        try:
            admins = ADMINS_SHEET.get_all_records()
            for admin in admins:
                admin_username = admin.get('username', '').strip()
                admin_password = admin.get('password', '').strip()
                if admin_username == username:
                    if not admin_password:
                        logging.info('Response: POST /admin_login - Status: 200, Error: Invalid credentials')
                        return render_template('admin_login.html', error='Invalid credentials')

                    try:
                        stored_password = admin_password.encode('utf-8')
                        if bcrypt.checkpw(password, stored_password):
                            session.pop('worker_id', None)
                            session['admin_id'] = username
                            session.permanent = True
                            logging.info(f"Response: POST /admin_login - Status: 302, Redirect: admin_dashboard")
                            return redirect(url_for('admin_dashboard'))
                    except ValueError:
                        logging.info('Response: POST /admin_login - Status: 200, Error: Invalid password format')
                        return render_template('admin_login.html', error='Invalid password format')

            logging.info('Response: POST /admin_login - Status: 200, Error: Invalid credentials')
            return render_template('admin_login.html', error='Invalid credentials')
        except Exception as e:
            logging.info(f"Response: POST /admin_login - Status: 200, Error: Error accessing admins: {str(e)}")
            return render_template('admin_login.html', error=f'Error accessing admins: {str(e)}')

    logging.info('Request: GET /admin_login')
    logging.info('Response: GET /admin_login - Status: 200')
    return render_template('admin_login.html')

@app.route('/admin_dashboard')
def admin_dashboard():
    logging.info('Request: GET /admin_dashboard')
    if 'admin_id' not in session:
        logging.info('Response: GET /admin_dashboard - Status: 302, Redirect: admin_login')
        return redirect(url_for('admin_login'))

    logging.info(f"Response: GET /admin_dashboard - Status: 200, Admin: {session['admin_id']}")
    return render_template('admin_dashboard.html', admin=session['admin_id'])

@app.route('/add_worker', methods=['POST'])
def add_worker():
    logging.info(f"Request: POST /add_worker, Form data: {{'username': '{request.form.get('username')}', 'password': '<hidden>'}}")
    if 'admin_id' not in session:
        logging.info('Response: POST /add_worker - Status: 401, Error: Unauthorized')
        return jsonify({'success': False, 'error': 'Unauthorized'}), 401

    if not WORKERS_SHEET:
        logging.info('Response: POST /add_worker - Status: 503, Error: Service unavailable')
        return jsonify({'success': False, 'error': 'Service unavailable'}), 503

    try:
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            logging.info('Response: POST /add_worker - Status: 400, Error: Please provide both username and password')
            return jsonify({'success': False, 'error': 'Please provide both username and password'}), 400

        if len(password) < 8:
            logging.info('Response: POST /add_worker - Status: 400, Error: Password must be at least 8 characters')
            return jsonify({'success': False, 'error': 'Password must be at least 8 characters'}), 400

        password = password.encode('utf-8')
        hashed_password = bcrypt.hashpw(password, bcrypt.gensalt()).decode('utf-8')

        workers = WORKERS_SHEET.get_all_records()
        if any(worker.get('username', '').strip() == username for worker in workers):
            logging.info('Response: POST /add_worker - Status: 400, Error: Username already exists')
            return jsonify({'success': False, 'error': 'Username already exists'}), 400

        WORKERS_SHEET.append_row([username, hashed_password])
        logging.info(f"Response: POST /add_worker - Status: 200, Worker added: {username}")
        return jsonify({'success': True})
    except Exception as e:
        logging.info(f"Response: POST /add_worker - Status: 500, Error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin_logout')
def admin_logout():
    logging.info('Request: GET /admin_logout')
    session.pop('admin_id', None)
    session.pop('worker_id', None)
    logging.info('Response: GET /admin_logout - Status: 302, Redirect: admin_login')
    return redirect(url_for('admin_login'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)